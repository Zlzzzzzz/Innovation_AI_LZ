# Wallet Trust Scoring API

This is a simple FastAPI wrapper around the Week 4 trust scoring output.

## Project Structure

```text
wallet_trust_api/
├── api/
│   ├── __init__.py
│   └── app.py
├── data/
│   └── scoring_output.csv
├── docs/
│   └── api_usage.md
├── requirements.txt
└── README.md
```

## Quick Start

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Run the API:

```bash
uvicorn api.app:app --reload
```

3. Open the interactive docs:

```text
http://127.0.0.1:8000/docs
```

## Available Endpoints

- `GET /` → API overview
- `GET /health` → health check
- `GET /wallets?limit=20` → list sample wallets
- `GET /score/{wallet}` → get trust score for a wallet
