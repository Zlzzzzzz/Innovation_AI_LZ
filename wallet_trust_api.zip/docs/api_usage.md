# API Usage

## Start the server

```bash
uvicorn api.app:app --reload
```

## Test endpoints

### Home
```bash
curl http://127.0.0.1:8000/
```

### Health
```bash
curl http://127.0.0.1:8000/health
```

### List wallets
```bash
curl "http://127.0.0.1:8000/wallets?limit=5"
```

### Get wallet score
Replace the wallet address below with one from `/wallets`.

```bash
curl http://127.0.0.1:8000/score/0x8f2a55949006b2d7c4e4d4b9b5e1a2d1f3c1a001
```
