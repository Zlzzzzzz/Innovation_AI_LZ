from pathlib import Path
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI(
    title="Wallet Trust Scoring API",
    description="A simple MVP API for querying wallet trust scores.",
    version="1.0.0",
)

DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "scoring_output.csv"


def load_scores() -> pd.DataFrame:
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Missing scoring output file: {DATA_PATH}")
    return pd.read_csv(DATA_PATH)


class HealthResponse(BaseModel):
    status: str
    rows: int


class ScoreResponse(BaseModel):
    wallet: str
    human_score: float
    human_likelihood: str
    trust_tier: str
    score_reasons: str


@app.get("/")
def home():
    return {
        "message": "Wallet Trust Scoring API",
        "endpoints": ["/health", "/wallets", "/score/{wallet}"],
    }


@app.get("/health", response_model=HealthResponse)
def health():
    df = load_scores()
    return {"status": "ok", "rows": len(df)}


@app.get("/wallets")
def list_wallets(limit: int = 20):
    df = load_scores()
    wallets = df["wallet"].head(limit).tolist()
    return {"count": len(wallets), "wallets": wallets}


@app.get("/score/{wallet}", response_model=ScoreResponse)
def get_score(wallet: str):
    df = load_scores()
    result = df[df["wallet"] == wallet]
    if result.empty:
        raise HTTPException(status_code=404, detail="Wallet not found")
    row = result.iloc[0]
    return {
        "wallet": str(row["wallet"]),
        "human_score": float(row["human_score"]),
        "human_likelihood": str(row["human_likelihood"]),
        "trust_tier": str(row["trust_tier"]),
        "score_reasons": str(row["score_reasons"]),
    }
